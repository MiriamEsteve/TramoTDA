from setuptools import setup, find_packages

setup(
    name='tramoTDA',
    version='0.1',
    description='Trajectory monitoring using topological data analysis (TDA)',
    author='Miriam Esteve and Antonio Falco',
    author_email='miriam.estevecampello@uchceu.es',
    packages=find_packages(),
    install_requires=[
        'numpy',
        'matplotlib',
        'scipy',
        'scikit-learn',
        'persim',
        'ripser',
        'gudhi',
        'Pillow'
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)
