# TramoTDA

TramoTDA is a Python package for trajectory analysis using topological data analysis (TDA). 

## Installation

You can install the package using `pip`:

```bash
pip install .
```

## Usage

```python
from tramoTDA import TrajectoryAnalysis

analysis = TrajectoryAnalysis()
analysis.run_analysis()
```

## Features
1. Simulate trajectory data
2. Generate and plot persistence diagrams
3. Calculate and plot lifetime diagrams
4. Generate and plot persistence images
5. Compute and plot barycenter of persistence diagrams
6. Perform and evaluate classification of trajectories

## License

### Putting It All Together

Now, with the package structure in place, you can install your package locally by running the following command from the directory containing the `setup.py` file:

```bash
pip install .
```

After installation, you can use the package in your scripts as follows:

```python
from tramoTDA import TrajectoryAnalysis

analysis = TrajectoryAnalysis()
analysis.run_analysis()
```

This setup encapsulates all functionalities into a well-structured package, making it easy to maintain, extend, and use.